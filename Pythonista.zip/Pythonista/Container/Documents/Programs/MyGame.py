from scene import *
import ui
#defines cmp() as cmp() no longer exists natively in python 3.
def cmp(a, b):
    return (a > b) - (a < b) 
#Creates class with Scene. Scene allows to actually create a...well, Screen. The screen can be customised with different functions.
def switch
class Start_Screen (Scene):
	
	def setup(self):
		

class Game (Scene):
	#Setup allows customisation of screen. Allows changes to screen looks(i.e.background color,background image) and allows adding of SpriteNodes(basically sprites).
    def setup(self):
    	x=0
    	#makes the ground tiles go all the way across the screen.
    	while x < self.size.w + 1:
    		#Creates SpriteNode for ground and asserts a position for it.
    		self.ground = SpriteNode('plf:Ground_DirtMid', position=(x, 0))
    		#Adds the ground SpriteNode as a child. This actually makes the image appear on the screen
    		self.add_child(self.ground)
    		#Adds 64 to x each time so that the ground image moves 64 'points' at a time because the ground image is 54 'points' long.
    		x = x + 64
			#Simply sets background color. Hexadecimal color codes can be used.	
    	self.background_color = 'red'
    	#creates the player spritenode. self is used to say thst it is a part of the screen since screen has the self attribute to define itself.
    	self.player = SpriteNode('plf:Enemy_SlimeBlock_move')
    	#anchor point tells from which point on the sprite it is to be moved from. 0,0 is the bottom left corner and 1,1 is the top right.
    	self.player.anchor_point = (0.5,0)
    	#sets player sprite position. self.size.w is the width of the screen and self.size.h is height. 32 is the height of the ground.
    	self.player.position = (self.size.w/2,32)
    	#adds player spritenode as a child.
    	self.add_child(self.player)
    def update(self):
    	#To clean up code, a lot of (if bot all) stuff will be moved to its own function.
    	self.move_player()
    	
    
    
    
    
    def move_player(self):
    	#gravity() lets it recieve data from the tilting of the device.
    	g = gravity()
    	#uses cmp() to compare the x scale of the device’s tilt and gives either 1,0,or -1. Allows SpriteNode to flip so it is "looking" whichever way the phone is tilted.
    	self.player.x_scale = cmp(g.x,0)
    	#Must have abs() or it doesnt work. creates condition for stuff to happen. Any other always true statement will also work. abs() gives magnitude of a number without regard to signs. abs() disregards the -g.x values.
    	if abs(g.x) > 0.01:
    		#These help explain abs()
    		#print(abs(g.x))
    		#print(g.x)
    		Speed_Amp = 10
    		#x is the player SpriteNode's current x position.
    		x = self.player.position.x
    		#For comments on this line see ScreenBoundary.py
    		x = max(0 , min(self.size.w, x + g.x * Speed_Amp))
    		
    		self.player.position=(x,self.player.position.y)
    		'''
    		if touched == True:
    			self.player.position = (self.player.position)
    		else:
    			self.player.position = (x,32)
				'''
			#touch_began detects when the screen is touched and executes it’s code on touch.
    def touch_began(self,touch):
    	x,y = touch.location
    	move_action = Action.move_to(x,y,0.9,TIMING_SINODIAL)
    	self.player.run_action(move_action)
    	touched = True
    	


run(Game(), PORTRAIT,show_fps = True)
