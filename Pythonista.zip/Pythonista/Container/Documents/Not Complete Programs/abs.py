from scene import *
g = gravity()
while 1 == 1 :
	print (g.x)
	print(abs(g.x))
