def cmp(a, b):
    return (a > b) - (a < b) 

a=1
b=2
c =cmp(a,b)
print(c)

# when a<b 

a = 1 

b = 2 

print(cmp(a, b))   

  
# when a = b  

a = 2

b = 2 

print(cmp(a, b))   

  
# when a>b  

a = 3

b = 2 

print(cmp(a, b)) 

#result:
	#-1
	#0
	#1
