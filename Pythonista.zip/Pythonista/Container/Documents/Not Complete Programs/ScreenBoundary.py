    		x = max(0 , min(self.size.w, x + g.x))
    		#This should be the same as:
    			#RightBoundary = min(self.size.w, x + g.x)
    			#Which returns whichever is smaller out of the (screen’s width and the players position + (the tilt of the device * Value to amplify speed)) which means that if (the tilt of the device * Value to amplify speed) is bigger than the screen's width, then it will return the screen's width causing the self.player.position.x to stay at the screen's width until (the tilt of the device * Value to amplify speed)) is smaller than the screen's width. 
    			#Then,
    			#x = max(0,RightBoundary)
    			#x is to be set as the player SpriteNode's x position,
    			#max() now gets the RightBoundary values and checks which out of RightBoundary and 0 is bigger. (RightBoundary must be returning (the tilt of the device * Value to amplify speed)) instead of the screen's width to be lower than 0)
