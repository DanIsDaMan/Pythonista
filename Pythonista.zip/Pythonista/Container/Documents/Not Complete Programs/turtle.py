import turtle
turtle.write('Hello World')
