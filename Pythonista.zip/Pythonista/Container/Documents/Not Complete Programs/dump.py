    def update(self):
    	#To clean up code, a lot of (if bot all) stuff will be moved to its own function.
    	self.move_player()
    	
    
    
    
    
    def move_player(self):
    	#gravity() lets it recieve data from the tilting of the device.
    	g = gravity()
    	#uses cmp() to compare the x scale of the device’s tilt and gives either 1,0,or -1. Allows SpriteNode to flip so it is "looking" whichever way the phone is tilted.
    	self.player.x_scale = cmp(g.x,0)
    	#Must have abs() or it doesnt work. creates condition for stuff to happen. Any other always true statement will also work. abs() gives magnitude of a number without regard to signs. abs() disregards the -g.x values.
    	if abs(g.x) > 0.01:
    		#These help explain abs()
    		#print(abs(g.x))
    		#print(g.x)
    		Speed_Amp = 10
    		#x is the player SpriteNode's current x position.
    		#x = self.player.position.x
    		#For comments on this line see ScreenBoundary.py
    		#x = max(0 , min(self.size.w, x + g.x))
    		#self.player.position = (x,32)
