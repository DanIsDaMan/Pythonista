import os

builtin_images = [name for name in os.listdir(os.path.join(os.path.dirname(os.__file__), "../Textures")) if "@2x" not in name]
