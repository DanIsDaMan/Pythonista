import ui

v = ui.load_view()
v.present('present')
