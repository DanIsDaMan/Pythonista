import ui
from scene import *

times_tapped = 0

def button_tapped(button):
	global times_tapped
	if times_tapped == 0:
		button.title = 'What did I just say?'
		button.size_to_fit()
		times_tapped += 1
	elif times_tapped == 1:
		button.title = 'I said Don\'t Tap Me'
		times_tapped += 1
		button.size_to_fit()
	elif times_tapped == 2:
		button.title = 'Are you even listening to what I\'m saying!?'
		times_tapped += 1
		button.size_to_fit()
	elif times_tapped == 3:
		button.title = 'RIGHT, THAT\'S IT!!! I\'M NOT GOING TO TALK TO YOU ANYMORE!'
		times_tapped += 1
		button.size_to_fit()
	else:
		button.title = '' 
		button.width = 100
		button.height = 50
