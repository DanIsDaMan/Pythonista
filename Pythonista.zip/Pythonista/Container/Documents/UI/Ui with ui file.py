#This script will do the same thing as 'Ui without ui file' but with a lot less code.
#All the stuff for the button is configured in the .ui file.
#This is completely useless but demonstrates some of the core concepts of the ui module and using .pyui files.

#Imporya the ui and scene modules
import ui
from scene import *

#This is just a counter to keep track of how many times the button is tapped.
times_tapped = 0

#defines a function to execute when the button is tapped. Must have a sender attribute(I named it button)and,if in a class, a self attribute.
def button_tapped(button):
	global times_tapped
	#Makes the button stay in it's container even if the screen is rotated.
	button.flex = 'LRTB'
	if times_tapped == 0:
		#.title is the text on the button.
		button.title = 'What did I just say?'
		#.size_to_fit() resizes the button to fit the text.
		button.size_to_fit()
		times_tapped += 1
	elif times_tapped == 1:
		button.title = 'I said Don\'t Tap Me'
		times_tapped += 1
		button.size_to_fit()
	elif times_tapped == 2:
		button.title = 'Are you even listening to what I\'m saying!?'
		times_tapped += 1
		button.size_to_fit()
	elif times_tapped == 3:
		button.title = 'RIGHT,I\'M NOT GOING TO TALK TO YOU ANYMORE.'
		times_tapped += 1
		button.size_to_fit()
	else:
		button.title = '' 
		#Sets button width and height.
		button.width = 100
		button.height = 50
		
#Defines a function for the switch to execute when it is on or off really...
#Like the button it also needs a sender atteibute, ect.
def switch(switch):
	#Allows you to access other gui elements other than the one the function is for. Must be [VariableName] = [SenderAttribute].superview, where VariableName can be anything you want.
	x = switch.superview
	if x['switch1'].value == True:
		x['background'].background_color = 'black'
		x['Button_01'].title = 'Dark Mode for iOS'
		x['Button_01'].size_to_fit()
		x['label1'].text = '🤪'
	elif x['switch1'].value == False:
		#print(x['switch1'].value)
		x['background'].background_color = 'white'
		x['Button_01'].title = 'Switch is off'
	
	
ui.load_view('Ui with ui file').present('sheet')


