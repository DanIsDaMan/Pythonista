import ui

#This is what the button will be set to do when it is tapped.
def button_tapped(sender):
    sender.title = 'Hello'

x,y = ui.get_screen_size()
#This is the "base class" for anything that will go onto the screen
view = ui.View()                                      # This is the name that will appear at the top of the screen.
view.name = 'Button Test'                                    #This will be the background colour
view.background_color = 'white'                       #This is the creation of the button
button = ui.Button(title='Tap me!')                   # This centres the button
button.center = (view.width / 2, view.height / 2) 
#This makes the button 'flexible'. This means that if the screen is rotated, the button stays centred in its container.
button.flex = 'LRTB'                                  #Simply sets the action for the button when it is tapped. Dont put the brackets at the end of the function name when putting it down like this.
button.action = button_tapped                       #Adds the button to the screen
view.add_subview(button)                              #Presents the view in a certain way,(idk difference rn, I dont have an iPad.)On the iPhone, all views are presented in full-screen, but on the iPad, you can choose between 'sheet', 'popover' and 'fullscreen'.
view.present('sheet')                                 


