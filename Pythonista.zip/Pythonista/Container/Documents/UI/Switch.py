import ui

v = ui.load_view()
v.present('sheet')
